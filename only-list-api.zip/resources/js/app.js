import './bootstrap';

// React Components
import './components/books/view.jsx'